# ChatApplication_Server

`configuration.json` file and `Resources` directory is includes `Users` and `Channels` directory should be side of the server.jar file
